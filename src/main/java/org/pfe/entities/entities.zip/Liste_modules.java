package org.pfe.entities;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
@Entity
public class Liste_modules implements Serializable {
	public void setFiliere(Filiere filiere) {
		this.filiere = filiere;
	}

	@EmbeddedId
	private Liste_moduleId liste_moduelId;
	private String semestre_mod;

	@ManyToOne
	@MapsId("idModule")
	@JoinColumn(name="id_module",referencedColumnName = "id_module", insertable = false, updatable = false)

	private Module module;
	@ManyToOne
	@MapsId("idFiliere")
	@JoinColumn(name="id_filiere", referencedColumnName = "id_filiere", insertable = false, updatable = false)
	private Filiere filiere;

	
	
		
	public Liste_modules() {
		super();
	}

	public String getSemestre_mod() {
		return semestre_mod;
	}

	public void setSemestre_mod(String semestre_mod) {
		this.semestre_mod = semestre_mod;
	}

	public Liste_moduleId getListe_moduelId() {
		return liste_moduelId;
	}

	public void setListe_moduelId(Liste_moduleId liste_moduelId) {
		this.liste_moduelId = liste_moduelId;
	}

	public Module getModule() {
		return module;
	}

	public void setModule(Module module) {
		this.module = module;
	}

	public Filiere getFiliere() {
		return filiere;
	}

	public void setFilier(Filiere filiere) {
		this.filiere = filiere;
	}


}
