package org.pfe.entities;

public class Professeur {

}
