package org.pfe.entities;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.Where;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@SQLDelete(sql = "UPDATE filiere SET deleted = true WHERE id=?")
@Where(clause = "deleted=false")
public class Filiere {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id_filiere;
	@NotBlank(message = "ne doit pas etre null" )
	@NotNull
	private String nom;
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@NotNull(message = "la date ne doit pas etre null")
	private Date dateCreation;
	private boolean deleted = Boolean.FALSE;
	
	
	
	@ManyToOne(cascade = CascadeType.PERSIST,fetch =FetchType.EAGER)
    @JoinColumn(name="dept_id")
	@NotNull(message="ne doit pas etre null")
    private Departement dept;

	
	
	
	@OneToMany(mappedBy = "filiere")
	private List<Liste_modules> liste_modules;
	
	
	@ManyToMany
	@JoinTable(name="fil_modules",joinColumns = @JoinColumn(name="fil_id"),inverseJoinColumns = @JoinColumn(name="module_id") )
	private Set<Module> modules=new HashSet<>();

	
	

	@ManyToOne
    @JoinColumn(name="cycle_id")
	@NotNull(message="ne doit pas etre null")
    private Cycle cyc;
	@OneToOne
	@OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
	private User user;
	
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Filiere(@NotBlank(message = "ne doit pas etre null") @NotNull String nom,
			@NotNull(message = "la date ne doit pas etre null") Date dateCreation, Departement dept, Cycle cyc) {
		super();
		this.nom = nom;
		this.dateCreation = dateCreation;
		this.dept = dept;
		this.cyc = cyc;
	}

	public Set<Module> getModules() {
		return modules;
	}


	public void setModules(Set<Module> modules) {
		this.modules = modules;
	}
	public Filiere() {
		super();
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public Date getDateCreation() {
		return dateCreation;
	}


	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}


	public Departement getDept() {
		return dept;
	}


	public void setDept(Departement dept) {
		this.dept = dept;
	}


	public Cycle getCyc() {
		return cyc;
	}


	public void setCyc(Cycle cyc) {
		this.cyc = cyc;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public List<Liste_modules> getListe_modules() {
		return liste_modules;
	}

	public void setListe_modules(List<Liste_modules> liste_modules) {
		this.liste_modules = liste_modules;
	}

	public Long getId_filiere() {
		return id_filiere;
	}


	
	
	

}
