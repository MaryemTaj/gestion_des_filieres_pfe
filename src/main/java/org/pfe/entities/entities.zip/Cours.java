package org.pfe.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Cours {
	 
		@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
		private Long id_cours;
		private static final long serialVersionUID = 1L;
		
		private String nom;
		

		private int fichier_cours;
		private String type_cours;

		
		@ManyToOne
		@JoinColumn(name="id_module",referencedColumnName = "id_module")
		private Module module;

		public Cours() {
			super();
		}

		

		public String getNom() {
			return nom;
		}



		public void setNom(String nom) {
			this.nom = nom;
		}



		public int getFichier_cours() {
			return fichier_cours;
		}

		public void setFichier_cours(int fichier_cours) {
			this.fichier_cours = fichier_cours;
		}

		public String getType_cours() {
			return type_cours;
		}

		public void setType_cours(String type_cours) {
			this.type_cours = type_cours;
		}

		
		public Long getIs_cours() {
			return id_cours;
		}

		public void setIs_cours(Long is_cours) {
			this.id_cours = is_cours;
		}

		

		public Module getModule() {
			return module;
		}

		public void setModule(Module module) {
			this.module = module;
		}

		public Long getId_cours() {
			return id_cours;
		}

		@Override
		public String toString() {
			return this.nom ;
		}
		
		

}
