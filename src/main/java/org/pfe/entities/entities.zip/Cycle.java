package org.pfe.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Cycle implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(unique=true,nullable = false)
	private String nom;
	
	
	@OneToMany(mappedBy="cyc")
	private Set<Filiere> filList=new HashSet<>();


	public Cycle() {
		super();
	}


	public Cycle(String nom) {
		super();
		this.nom = nom;
		
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public Set<Filiere> getFilList() {
		return filList;
	}


	public void setFilList(Set<Filiere> filList) {
		this.filList = filList;
	}


	public Long getId() {
		return id;
	}
	


	
	
	
}
